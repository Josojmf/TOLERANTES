

#ifndef PIC32MZ_CONFIGURATIONBITS_H
#define	PIC32MZ_CONFIGURATIONBITS_H

void init_configuration_bits(void);


#endif	/* PIC32MZ_CONFIGURATIONBITS_H */

