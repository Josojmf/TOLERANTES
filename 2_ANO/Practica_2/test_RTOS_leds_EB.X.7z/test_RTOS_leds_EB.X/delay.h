

#ifndef DELAY_h
#define DELAY_h


#include <xc.h>

void delay_ms(unsigned int time_ms);
void delay_us(unsigned int time_us);

#endif
